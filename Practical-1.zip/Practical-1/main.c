#include <stdio.h>
#include <stdlib.h>
#include "testing.h"

int main() {
    init_testing();
    testTimeCost();
    return 0;
}
