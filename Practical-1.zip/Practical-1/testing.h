//
// Created by Lenovo on 28/02/2021.
//

#ifndef PRACTICAL_1_TESTING_H
#define PRACTICAL_1_TESTING_H

#endif //PRACTICAL_1_TESTING_H

// Have to be called before testing runs.
void init_testing();

// The function test the cost of different implementations
void testTimeCost();

// The function test the space cost of different implementations
void testSpaceCost();